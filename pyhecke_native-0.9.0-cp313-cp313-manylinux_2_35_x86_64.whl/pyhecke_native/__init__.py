from .pyhecke_native import *

__doc__ = pyhecke_native.__doc__
if hasattr(pyhecke_native, "__all__"):
    __all__ = pyhecke_native.__all__