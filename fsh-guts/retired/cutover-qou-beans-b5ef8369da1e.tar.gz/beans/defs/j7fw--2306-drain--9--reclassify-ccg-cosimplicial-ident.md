---
# j7fw
title: '#2306 drain #9: reclassify ccg_cosimplicial_identities lemma→definition (cosimplicial-object axioms)'
status: completed
type: task
priority: normal
created_at: 2026-06-14T17:29:07Z
updated_at: 2026-06-14T18:22:27Z
parent: w5q7
---

User pick (#2306 thread, opt 2). Identities are defining axioms over abstract maps; honest form is a definition (structure), not an asserted lemma. Block-kind + .md/.ts change.
