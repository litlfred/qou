---
# cj317
title: 'Conjecture carrier: QCollatz (QCollatz.lean) — §3b, famous-open (aspirational §3b encoding)'
status: todo
type: task
priority: low
tags:
    - reorg-2026-10-04
created_at: 2026-07-05T13:20:00Z
updated_at: 2026-10-04T15:25:52Z
parent: qcz14
---

§3b conjecture-class Lean carrier `instance : QCollatz := sorry` at folio/quantum-observable-universe/lean/QOU/AppendixSurreals/QCollatz.lean:39. The sorry IS the conjecture (per AGENTS.md §3b) — do NOT fabricate an instance (audit-dodge). Category: famous-open (aspirational §3b encoding). Track backing/derivation status; advance only via genuine derivation or owner-directed reframing. Parent: b9cj.
