---
# b9q1
title: 'Prove qGaussianObstructionAtQ0 (mass-theory/q-gaussian-obstruction-at-q0.lean:29)'
status: completed
type: task
priority: normal
parent: b9ms
created_at: 2026-07-05T11:15:00Z
updated_at: 2026-07-05T11:30:00Z
---

Real-analysis divergence: q>1, T m >= q^(m(m-1)/2) => T unbounded. tendsto_pow_atTop / pow_unbounded_of_one_lt, monotone exponent -> sup. Magnitude-side structural fact. Verify lean-direct.
