---
# cj1b7
title: 'Conjecture carrier: DiophantineBirthday (DiophantineBirthday.lean) — §3b, famous-open (aspirational §3b encoding)'
status: todo
type: task
priority: low
tags:
    - reorg-2026-10-04
created_at: 2026-07-05T13:20:00Z
updated_at: 2026-10-04T15:25:49Z
parent: qou-3kkl
---

§3b conjecture-class Lean carrier `instance : DiophantineBirthday := sorry` at folio/quantum-observable-universe/lean/QOU/AppendixSurreals/DiophantineBirthday.lean:50. The sorry IS the conjecture (per AGENTS.md §3b) — do NOT fabricate an instance (audit-dodge). Category: famous-open (aspirational §3b encoding). Track backing/derivation status; advance only via genuine derivation or owner-directed reframing. Parent: b9cj.
