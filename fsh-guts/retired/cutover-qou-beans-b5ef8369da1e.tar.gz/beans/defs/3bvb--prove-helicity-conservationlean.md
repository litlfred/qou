---
# 3bvb
title: Prove helicity_conservation.lean
status: completed
type: task
priority: normal
created_at: 2026-06-24T04:30:34Z
updated_at: 2026-06-24T04:32:25Z
parent: niq9
---

