---
# 6w9s
title: 'Session: fix Borromean R-matrix inverse (1iqq) — matrix-inverse of forward R, verify bar-sym + diagonal cyclotomic'
status: scrapped
type: epic
created_at: 2026-07-04T14:44:05Z
updated_at: 2026-07-04T14:44:05Z
---

